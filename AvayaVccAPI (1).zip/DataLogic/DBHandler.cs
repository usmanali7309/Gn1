﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using Npgsql;
using AvayaVcc;
using System.Text.RegularExpressions;

namespace DBAccess
{
    public class DBHandler
    {
        public static string Connectionstring;      

        public DBHandler()
        {
            Connectionstring = Startup.StaticConfig.GetConnectionString("DefaultConnection");
        }
        public DataTable ExecuteDataTable(string query)
        {
            NpgsqlConnection cnn = new NpgsqlConnection(Connectionstring);
            DataTable temp = new DataTable();
            NpgsqlDataAdapter da = new NpgsqlDataAdapter();
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand(query, cnn);                
                cmd.CommandTimeout = 0;
                da.SelectCommand = cmd;
                da.Fill(temp);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            finally
            {
                cnn.Close();
                cnn.Dispose();
                NpgsqlConnection.ClearAllPools();
                da.Dispose();
            }
            return temp;
        }

        public int ExecuteNonQuery(string query)
        {
            NpgsqlConnection cnn = new NpgsqlConnection(Connectionstring);
            NpgsqlCommand cmd = new NpgsqlCommand(query, cnn);
            if (query.StartsWith("CREATE") | query.StartsWith("create") | query.StartsWith("Alter") | query.StartsWith("INSERT") | query.StartsWith("insert") | query.StartsWith("UPDATE") | query.StartsWith("update") | query.StartsWith("DELETE") | query.StartsWith("delete"))
            {
                cmd.CommandType = CommandType.Text;
            }
            else
            {
                cmd.CommandType = CommandType.StoredProcedure;
            }
            int retval;
            try
            {
                cnn.Open();
                retval = cmd.ExecuteNonQuery();
            }
            catch (Exception exp)
            {
                throw exp;
            }
            finally
            {
                cnn.Close();
                cnn.Dispose();
                NpgsqlConnection.ClearAllPools();
            }
            return retval;
        }

        public object ExecuteScalar(string query)
        {
            object retval = null;
            NpgsqlConnection cnn = new NpgsqlConnection(Connectionstring);
            NpgsqlCommand cmd = new NpgsqlCommand(query, cnn);
            if (query.StartsWith("SELECT") | query.StartsWith("select") | query.StartsWith("Select") | query.StartsWith(" SELECT") | query.StartsWith(" select") | query.StartsWith(" Select"))
            {
                cmd.CommandType = CommandType.Text;
            }
            else
            {
                cmd.CommandType = CommandType.StoredProcedure;
            }
            try
            {
                cnn.Open();
                retval = cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cnn.Close();
                cnn.Dispose();
                NpgsqlConnection.ClearAllPools();
            }
            return retval;
        }


        public string SafeSqlLiteral(System.Object theValue, System.Object theLevel)
        {
            // Written by user CWA, CoolWebAwards.com Forums. 2 February 2010
            // http://forum.coolwebawards.com/threads/12-Preventing-SQL-injection-attacks-using-C-NET

            // intLevel represent how thorough the value will be checked for dangerous code
            // intLevel (1) - Do just the basic. This level will already counter most of the SQL injection attacks
            // intLevel (2) -   (non breaking space) will be added to most words used in SQL queries to prevent unauthorized access to the database. Safe to be printed back into HTML code. Don't use for usernames or passwords

            string strValue = theValue + "";
            int intLevel = (int)theLevel;

            if (strValue != null)
            {
                if (intLevel > 0)
                {
                    strValue = strValue.Replace("'", "''"); // Most important one! This line alone can prevent most injection attacks
                    strValue = strValue.Replace("--", "");
                    strValue = strValue.Replace("[", "[[]");
                    strValue = strValue.Replace("%", "[%]");
                }
                if (intLevel > 1)
                {
                    string[] myArray = new string[] { "xp_ ", "update ", "insert ", "select ", "drop ", "alter ", "create ", "rename ", "delete ", "replace " };
                    int i = 0;
                    int i2 = 0;
                    int intLenghtLeft = 0;
                    for (i = 0; i < myArray.Length; i++)
                    {
                        string strWord = myArray[i];
                        Regex rx = new Regex(strWord, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                        MatchCollection matches = rx.Matches(strValue);
                        i2 = 0;
                        foreach (Match match in matches)
                        {
                            GroupCollection groups = match.Groups;
                            intLenghtLeft = groups[0].Index + myArray[i].Length + i2;
                            strValue = strValue.Substring(0, intLenghtLeft - 1) + "&nbsp;" + strValue.Substring(strValue.Length - (strValue.Length - intLenghtLeft), strValue.Length - intLenghtLeft);
                            i2 += 5;
                        }
                    }
                }
                return strValue;
            }
            else
            {
                return strValue;
            }
        }

    }
}
