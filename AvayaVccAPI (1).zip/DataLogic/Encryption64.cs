﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Xml;
using System.Configuration;

namespace AgnoCon
{
    public class Encryption64
    {
        public string PassW = "AB45XS87";
        // Use DES CryptoService with Private key pair
        private byte[] key = { }; // we are going to pass in the key portion in our method calls
        private byte[] IV = { 80, 108, 67, 75, 101, 121, 87, 83 };

        // Use for Security
        private byte[] keyS = { };
        private byte[] IVS = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };

        // Use for Security
        public string Decrypt(string stringToDecrypt)
        {
            byte[] inputByteArray = new byte[stringToDecrypt.Length + 1];
            try
            {
                keyS = System.Text.Encoding.UTF8.GetBytes(PassW.Substring(0, 8));
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                inputByteArray = Convert.FromBase64String(stringToDecrypt.Replace(" ", "+"));
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(keyS, IVS), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                System.Text.Encoding encoding = System.Text.Encoding.UTF8;
                return encoding.GetString(ms.ToArray());
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }
        // Use for Security
        public string Encrypt(string stringToEncrypt)
        {
            try
            {
                keyS = System.Text.Encoding.UTF8.GetBytes(PassW.Substring(0, 8));
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(keyS, IVS), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                return Convert.ToBase64String(ms.ToArray());
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public object RandomNumberGenerator(int length)
        {
            System.Security.Cryptography.RandomNumberGenerator rng = System.Security.Cryptography.RandomNumberGenerator.Create();
            char[] chars = new char[length];
            string validChars = "A1B5C2D6E3FG4H7I5J8K6L9M7NO8PQ9RS1TU2VW3XY4Z";
            for (int i = 0; i < length; i++)
            {
                byte[] bytes = new byte[1];
                rng.GetBytes(bytes);
                Random rnd = new Random(bytes[0]);
                chars[i] = validChars[rnd.Next(0, 43)];
            }
            return (new string(chars));
        }


    }
}