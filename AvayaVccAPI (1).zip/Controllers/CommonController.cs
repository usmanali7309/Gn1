﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace AvayaVcc.Controllers
{
    [Route("[controller]/api/[action]")]
    [ApiController]
    public class CommonController : Controller
    {
        private IConfiguration configuration;

        public CommonController(IConfiguration iConfig)
        {
            configuration = iConfig;
        }

        DBAccess.DBHandler dh = new DBAccess.DBHandler();
        LogWriter Lobjlogs = LogWriter.Instance;

        public string DtToJSON(DataTable table)
        {
            string JSONString = string.Empty;
            JSONString = JsonConvert.SerializeObject(table);
            JSONString = JSONString.Replace("[", "");
            JSONString = JSONString.Replace("]", "");
            return JSONString;
        }
        public IActionResult Index()
        {
            return View();
        }


        [HttpGet]
        public object checkuserlist()
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");

            DataRow dr;
            dr = dtmain.NewRow();
            dr["Status"] = "Success";
            dr["Status_Description"] = "";
            dtmain.Rows.Add(dr);

            return DtToJSON(dtmain);
        }

        [HttpGet]
        public object skillset_list()
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");

            DataTable dt = dh.ExecuteDataTable("select skill_id,skill_name,status from config_skillset where status='Active'");
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }

        [HttpPost]
        public object create_skillset(string skillname)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");

            DataTable dt = dh.ExecuteDataTable("select skill_id,skill_name from config_skillset where skill_name='" + skillname + "'");
            if (dt.Rows.Count > 0)
            {
                DataRow dr;
                dr = dtmain.NewRow();
                dr["Status"] = "Failed";
                dr["Status_Description"] = "Skill Name already exist";
                dtmain.Rows.Add(dr);
            }
            else
            {
                string com = "insert into config_skillset(skill_name,created_date,status) values('" + skillname + "',now(),'Active');";
                dh.ExecuteNonQuery(com);
                DataRow dr;
                dr = dtmain.NewRow();
                dr["Status"] = "Success";
                dr["Status_Description"] = "";
                dtmain.Rows.Add(dr);
            }

            return DtToJSON(dtmain);
        }


        [HttpGet]
        public object active_delete_userlist(string emailid)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");


            int com = dh.ExecuteNonQuery("UPDATE public.user_details SET status = 'Active'  where email_id='" + emailid + "' ");
            DataRow dr;
            dr = dtmain.NewRow();
            dr["Status"] = "Success";
            dr["Status_Description"] = "Successfully Deleted";

            dtmain.Rows.Add(dr);

            return "[" + DtToJSON(dtmain) + "]";

        }
        [HttpGet]
        public object active_delete_skillset(string skillname)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");


            int com = dh.ExecuteNonQuery("UPDATE public.config_skillset SET status = 'Active'  where skill_name='" + skillname + "'");
            DataRow dr;
            dr = dtmain.NewRow();
            dr["Status"] = "Success";
            dr["Status_Description"] = "Successfully Deleted";

            dtmain.Rows.Add(dr);

            return "[" + DtToJSON(dtmain) + "]";

        }



        [HttpPost]
        public object update_skillset(string skillname, string id)

        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            DataTable dt = dh.ExecuteDataTable("select skill_id,skill_name from config_skillset where skill_name='" + skillname + "'");
            if (dt.Rows.Count > 0)
            {
                DataRow dr;
                dr = dtmain.NewRow();
                dr["Status"] = "Failed";
                dr["Status_Description"] = "Skill Name already exist";
                dtmain.Rows.Add(dr);
            }
            else
            {
                string com = "UPDATE public.config_skillset SET skill_name ='" + skillname + "', created_date = now(), status ='Active' WHERE skill_id ='" + id + "'";
                DataTable dt1 = dh.ExecuteDataTable(com);
                DataRow dr;
                dr = dtmain.NewRow();
                dr["Status"] = "Success";
                dr["Status_Description"] = "updated Successfully";
                dtmain.Rows.Add(dr);
            }
            return "[" + DtToJSON(dtmain) + "]";

        }



        [HttpGet]
        public object delete_skillset(string skillname)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");


            string com = "UPDATE public.config_skillset SET status = 'Inactive'  where skill_name='" + skillname + "' ";
            DataTable dt = dh.ExecuteDataTable(com);
            DataRow dr;
            dr = dtmain.NewRow();
            dr["Status"] = "Success";
            dr["Status_Description"] = "Successfully Deleted";

            dtmain.Rows.Add(dr);

            return "[" + DtToJSON(dtmain) + "]";

        }



        [HttpGet]
        public object delete_userlist(string emailid)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");


            int com = dh.ExecuteNonQuery("UPDATE public.user_details SET status = 'Inactive'  where email_id='" + emailid + "' ");
            DataRow dr;
            dr = dtmain.NewRow();
            dr["Status"] = "Success";
            dr["Status_Description"] = "Successfully Deleted";

            dtmain.Rows.Add(dr);

            return "[" + DtToJSON(dtmain) + "]";

        }

        [HttpGet]
        public object update_userlist(string role, string emailid, string skill_id, string space_id)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");


            int com = dh.ExecuteNonQuery("UPDATE public.user_details SET role = '" + role + "'  where email_id='" + emailid + "' ");
            int com1 = dh.ExecuteNonQuery("UPDATE public.user_skillset SET skill_id = '" + skill_id + "'  where space_id='" + space_id + "' ");
            DataRow dr;
            dr = dtmain.NewRow();
            dr["Status"] = "Success";
            dr["Status_Description"] = "Successfully Deleted";

            dtmain.Rows.Add(dr);

            return "[" + DtToJSON(dtmain) + "]";

        }

        [HttpGet]
        public object user_login(string email_id)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");

            DataTable dt = dh.ExecuteDataTable("select * from user_details where email_id='" + email_id + "'");
            if (dt.Rows.Count > 0)
            {
                dtmain.Columns.Add("UserId");
                dtmain.Columns.Add("Email_id");
                dtmain.Columns.Add("Space_Id");
                dtmain.Columns.Add("Role");
                dtmain.Columns.Add("Display_Name");
                DataRow dr;
                dr = dtmain.NewRow();
                dr["Status"] = "Success";
                dr["Status_Description"] = "";
                dr["UserId"] = dt.Rows[0]["user_id"].ToString();
                dr["Email_id"] = dt.Rows[0]["email_id"].ToString();
                dr["Display_Name"] = dt.Rows[0]["diaplay_name"].ToString();
                dr["Space_Id"] = dt.Rows[0]["space_id"].ToString();
                dr["Role"] = dt.Rows[0]["role"].ToString();
                dtmain.Rows.Add(dr);
            }
            else
            {
                DataRow dr;
                dr = dtmain.NewRow();
                dr["Status"] = "Failed";
                dr["Status_Description"] = "You are not authorized. Please try later";
                dtmain.Rows.Add(dr);
            }


            return DtToJSON(dtmain);
        }

        [HttpGet]
        public object user_list()
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");

            DataTable dt = dh.ExecuteDataTable("SELECT us.user_id, us.space_id, diaplay_name, first_name, last_name, email_id, phone_no, role, u.status, us.skill_id,cs.skill_name FROM public.user_details u inner join user_skillset us on u.user_id = us.user_id inner join config_skillset cs on us.skill_id = cs.skill_id;");
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }


        [HttpGet]
        public object skillsetlist()
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");

            DataTable dt = dh.ExecuteDataTable("SELECT skill_id,skill_name,status from config_skillset");
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }


        [HttpPost]
        public object userdetails_save(Models.Common.User_Save obj)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");

            DataTable dt = dh.ExecuteDataTable("select user_id from user_details where email_id='" + obj.Email_id + "'");
            if (dt.Rows.Count > 0)
            {
                DataRow dr;
                dr = dtmain.NewRow();
                dr["Status"] = "Failed";
                dr["Status_Description"] = "User already exist";
                dtmain.Rows.Add(dr);
            }
            else
            {
                string com = @"insert into user_details(space_id,diaplay_name,first_name,last_name,email_id,phone_no,role,status,created_date) 
                    values('" + obj.SpaceID + "','" + obj.Display_Name + "','" + obj.First_Name + "','" + obj.Last_Name + "','" + obj.Email_id + "','" + obj.Phone_No + "','" + obj.Role + "','Active',now())";
                if (dh.ExecuteNonQuery(com) > 0)
                {
                    dt = dh.ExecuteDataTable("select user_id from user_details where email_id='" + obj.Email_id + "'");
                    dh.ExecuteNonQuery("insert into user_skillset(user_id,space_id,skill_id) values('" + dt.Rows[0][0].ToString() + "','" + obj.SpaceID + "','" + obj.SkillSet + "')");
                    dh.ExecuteNonQuery("insert into agents(user_id,space_id,status,state) values('" + dt.Rows[0][0].ToString() + "','" + obj.SpaceID + "','Logged Out','Waiting')");

                    DataRow dr;
                    dr = dtmain.NewRow();
                    dr["Status"] = "Success";
                    dr["Status_Description"] = "";
                    dtmain.Rows.Add(dr);
                }



            }

            return DtToJSON(dtmain);
        }

        [HttpPost]
        public object user_agent_status(Models.Common.Agent_State obj)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");

            DataTable dt = dh.ExecuteDataTable("select * from agent_status_update(" + obj.User_id + ",'" + obj.User_Status + "')");
            if (dt.Rows.Count > 0)
            {
                DataRow dr;
                dr = dtmain.NewRow();
                dr["Status"] = "Success";
                dr["Status_Description"] = "";
                dtmain.Rows.Add(dr);
            }
            return DtToJSON(dtmain);
        }

        [HttpPost]
        public object customer_insert(Models.Common.Customer_Details obj)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");

            DataTable dt = dh.ExecuteDataTable("select * from customer_details_insert('" + obj.Customer_Name + "','" + obj.Customer_Email + "','" + obj.Customer_Phone + "','" + obj.Customer_SkillSet + "');");
            if (dt.Rows.Count > 0)
            {
                dtmain.Columns.Add("uuid");
                DataRow dr;
                dr = dtmain.NewRow();
                dr["Status"] = "Success";
                dr["Status_Description"] = "";
                dr["uuid"] = dt.Rows[0][0].ToString();
                dtmain.Rows.Add(dr);
            }
            return DtToJSON(dtmain);
        }

        [HttpGet]
        public object agent_Availbility(string uuid)
        {

            string spaceid = "";
            DataTable dt = dh.ExecuteDataTable("select * from agent_availbility('" + uuid + "');");
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                Lobjlogs.WriteToLog("WEB_API.txt", "--------------------------------------------");
                Lobjlogs.WriteToLog("WEB_API.txt", "START : AT " + DateTime.Now + "");
                Lobjlogs.WriteToLog("WEB_API.txt", dt.Rows[0][0].ToString());
                spaceid = dt.Rows[0][0].ToString();
                //return spaceid;
            }            
            return spaceid;
        }

        string Check_Agent(string uuid)
        {
            string spaceid = "";
            DataTable dt = dh.ExecuteDataTable("select * from agent_availbility('" + uuid + "');");
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                Lobjlogs.WriteToLog("WEB_API.txt", "--------------------------------------------");
                Lobjlogs.WriteToLog("WEB_API.txt", "START : AT " + DateTime.Now + "");
                Lobjlogs.WriteToLog("WEB_API.txt", dt.Rows[0][0].ToString());
                spaceid = dt.Rows[0][0].ToString();
                return spaceid;
            }
            else
            {
                Check_Agent(uuid);
            }

            return spaceid;
        }


        [HttpGet]
        public object agent_status(string customername, string spaceid,string status)
        {
            Lobjlogs.WriteToLog("WEB_API.txt", "--------------------------------------------");
            Lobjlogs.WriteToLog("WEB_API.txt", "START : AT " + DateTime.Now + "");
            Lobjlogs.WriteToLog("WEB_API.txt", "Customername:"+ customername + " Spaceid:"+spaceid+" Status:"+status);
            if(status=="On Call")
            {
                dh.ExecuteNonQuery("update agents set state='On Call',calls_answered=calls_answered+1,last_bridge_start=extract(epoch from current_timestamp)::integer where space_id='" + spaceid + "'");
            }
            else if(status == "Call Ended")
            {
                dh.ExecuteNonQuery("update agents set state='Waiting',last_bridge_end=extract(epoch from current_timestamp)::integer,talk_time=talk_time+((extract(epoch from current_timestamp)::integer)-last_bridge_start) where space_id='" + spaceid + "'");
            }
            return "";
        }

        [HttpGet]
        public object customer_call_status(string uuid, string status)
        {
            Lobjlogs.WriteToLog("WEB_API.txt", "--------------------------------------------");
            Lobjlogs.WriteToLog("WEB_API.txt", "START : AT " + DateTime.Now + "");
            Lobjlogs.WriteToLog("WEB_API.txt", "UUid:" + uuid + " Status:" + status);
            if (status == "Call Connected")
            {
                dh.ExecuteNonQuery("update cdr set answered=now() where uuid='"+uuid+"' and answered is null");
            }
            else if (status == "Call Ended")
            {
                dh.ExecuteNonQuery("update cdr set end_time=now() where uuid='" + uuid + "' and end_time is null");
                dh.ExecuteNonQuery("delete from calls where uuid='" + uuid + "'");
            }
            return "";
        }


        [HttpGet]
        public object customer_call_end(string uuid)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");

            dh.ExecuteNonQuery("delete from calls where uuid='"+ uuid + "'");
            dh.ExecuteNonQuery("update cdr set end_time=now() where uuid='" + uuid + "' and end_time is null");

            return  DtToJSON(dtmain);
        }

    }
}
