﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;

namespace AvayaVcc.Controllers
{
    [Route("[controller]/api/[action]")]
    [ApiController]
    public class ReportsController : Controller
    {
        private IConfiguration configuration;

        public ReportsController(IConfiguration iConfig)
        {
            configuration = iConfig;
        }

        DBAccess.DBHandler dh = new DBAccess.DBHandler();
        LogWriter Lobjlogs = LogWriter.Instance;

        public string DtToJSON(DataTable table)
        {
            string JSONString = string.Empty;
            JSONString = JsonConvert.SerializeObject(table);
            JSONString = JSONString.Replace("[", "");
            JSONString = JSONString.Replace("]", "");
            return JSONString;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public object Admin_Dashboard_Hours()
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select * from admin_dashboard_chart();";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;
            return "[" + DtToJSON(dtmain) + "]";
        }

        [HttpGet]
        public object Customer_latest()
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select cast(cd.start_time::date as text) as cdate,TO_CHAR(cd.start_time,'HH24:mi:SS') as stime,TO_CHAR(cd.end_time,'HH24:mi:SS') as etime,cd.customer_name,cd.customer_email,cd.customer_phone,ss.skill_name, case when cd.answered is not null then 'Connected' else 'Not Connected' end as status ,ud.diaplay_name from cdr cd 
                        left join user_details ud on ud.space_id=cd.agent_space_id inner join config_skillset ss on cast(ss.skill_id as character varying)=cd.customer_skillset_id where cast(cd.uuid as text) not in (select uuid from calls) order by cd.ref_id desc limit 10;";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }

        [HttpGet]
        public object Active_Customers()
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select cast(cd.start_time::date as text) as cdate,TO_CHAR(cd.start_time,'HH24:mi:SS') as stime,cd.customer_name,cd.customer_email,cd.customer_phone,ss.skill_name, case when cd.answered is not null then 'Connected' else 'Waiting' end as status ,case when cd.answered is not null then ud.diaplay_name else '-' end as diaplay_name from cdr cd 
left join user_details ud on ud.space_id=cd.agent_space_id  inner join config_skillset ss on cast(ss.skill_id as character varying)=cd.customer_skillset_id
where cast(cd.uuid as text) in (select uuid from calls) order by cd.ref_id desc limit 10;";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }

        [HttpGet]
        public object Customer_call_report(DateTime fromdate, DateTime todate)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select cast(cd.start_time::date as text) as cdate,TO_CHAR(cd.start_time,'HH24:mi:SS') as stime,TO_CHAR(cd.end_time,'HH24:mi:SS') as etime,TO_CHAR((cd.end_time-cd.start_time) ,'HH24:mi:SS') as duration,cd.customer_name,cd.customer_email,cd.customer_phone,ss.skill_name, case when cd.answered is not null then 'Connected' else 'Not Connected' end as status ,ud.diaplay_name from cdr cd 
                        left join user_details ud on ud.space_id=cd.agent_space_id inner join config_skillset ss on cast(ss.skill_id as character varying)=cd.customer_skillset_id
                        where start_time between '"+ fromdate + "' and '"+ todate.AddDays(1) + "' order by cd.ref_id;";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }

        [HttpGet]
        public object Agent_Dashboard(string userid,DateTime fromdate)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select * from agent_dashboard("+userid+",'"+ fromdate + "');";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;
            return  DtToJSON(dtmain);
        }

        [HttpGet]
        public object Agent_Dashboard_Hours(string userid, DateTime fromdate)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select * from agent_dashboard_hours(" + userid + ",'" + fromdate + "');";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;
            return "["+DtToJSON(dtmain)+"]";
        }


        [HttpGet]
        public object Agent_Sumamry(DateTime fromdate,DateTime todate)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select * from agent_summary('"+ fromdate + "','"+ todate.AddDays(1) + "');";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }

        [HttpGet]
        public object SkillSet_Sumamry(DateTime fromdate, DateTime todate)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select * from skillset_summary('" + fromdate + "','" + todate.AddDays(1) + "');";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }


        [HttpGet]
        public object skillset_callvolume(DateTime fromdate, DateTime todate)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select * from skillset_callvolume('" + fromdate + "','" + todate.AddDays(1) + "');";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }

        [HttpGet]
        public object Agent_callvolume(DateTime fromdate, DateTime todate)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select * from agent_callvolume('" + fromdate + "','" + todate.AddDays(1) + "');";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }

        [HttpGet]
        public object statuswise_callvolume(DateTime fromdate, DateTime todate)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select * from statuswise_callvolume('" + fromdate + "','" + todate.AddDays(1) + "');";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }

        [HttpGet]
        public object hourly_callvolume(DateTime fromdate, DateTime todate)
        {
            DataTable dtmain = new DataTable();
            dtmain.Columns.Add("Status");
            dtmain.Columns.Add("Status_Description");
            string com = @"select * from hourly_callvolume('" + fromdate + "','" + todate.AddDays(1) + "');";
            DataTable dt = dh.ExecuteDataTable(com);
            dtmain = dt;

            return "[" + DtToJSON(dtmain) + "]";
        }

    }
}
