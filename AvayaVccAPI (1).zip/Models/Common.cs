﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AvayaVcc.Models
{
    public class Common
    {
        public class User_Save
        {
            public string Email_id { get; set; }
            public string Display_Name { get; set; }
            public string First_Name { get; set; }
            public string Last_Name { get; set; }
            public string Phone_No { get; set; }
            public string SpaceID { get; set; }
            public string Role { get; set; }
            public string SkillSet { get; set; }
        }

        public class Agent_State
        {
            public string User_id { get; set; }
            public string User_Status { get; set; }
        }

        public class Customer_Details
        {
            public string Customer_Name { get; set; }
            public string Customer_Email { get; set; }
            public string Customer_Phone { get; set; }
            public string Customer_SkillSet { get; set; }
        }
    }
}
